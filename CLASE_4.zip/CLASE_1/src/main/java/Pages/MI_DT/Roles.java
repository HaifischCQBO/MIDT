package Pages.MI_DT;

import Helpers.Helpers;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Roles {

    public WebDriver driver; //Declaro Objeto Driver.
    public Helpers helpers;

    public Roles(WebDriver driver) {  //Metodo Constructor de la Clase.
        this.driver = driver;
        helpers = new Helpers(driver);
    }

    /**
     * ---------------------------------------------------------------------------------------------------------
     * WebElements // WebElements // WebElements // WebElements // WebElements //
     * WebElements // WebElements //
     * ---------------------------------------------------------------------------------------------------------
     */
    public By botonTrabajador = By.id("btn-trabajador");
    public By botonEmpleador = By.id("btn-empleador");
    public By botonDirigenteSindical = By.id("btn-sindicato");
    //public By boton_manual_usuario = By.xpath("//button[@class='ui small button blue basic']");
    public By boton_manual_usuario = By.xpath("//div[@id='roles-right-panel']/div[@class='fadeIn']/div[contains(@class, 'ui')]/button[contains(@class, 'small')]");
    //public By boton_verificador_documentos = By.xpath("//button[@class='ui tiny button blue basic']");
    public By boton_verificador_documentos = By.xpath("//div[@id='roles-right-panel']/div[@class='fadeIn']/div[contains(@class, 'ui')]/button[contains(@class, 'tiny')]");
    /**
     * -----------------------------------------------------------------------------------------------------------
     * Funciones // Funciones // Funciones // Funciones // Funciones // Funciones //
     * Funciones // Funciones
     * -----------------------------------------------------------------------------------------------------------
     */

    public void seleccionPerfilTrabajador() {
        helpers.Click(botonTrabajador);
    }

    public void seleccionPerfilTipoEmpleador() {
        helpers.Click(botonEmpleador);
    }

    public void seleccionPerfilSindicato() {
        helpers.Click(botonDirigenteSindical);
    }

    public void clickBotonManualUsuario() {
        helpers.Click(boton_manual_usuario);
    }

    public void clickBotonVerficidorDocumentos() {
        helpers.Click(boton_verificador_documentos);
    }
}