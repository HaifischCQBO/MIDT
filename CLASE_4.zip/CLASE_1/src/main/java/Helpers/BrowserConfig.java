package Helpers;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class BrowserConfig {
	
	private WebDriver driver;

	Helpers helpers= new Helpers();

	
	public WebDriver setUpBrowser() {
		System.setProperty("webdriver.chrome.driver", 
				"src/drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
		driver.manage().window().maximize();

		return driver;
	}
}
