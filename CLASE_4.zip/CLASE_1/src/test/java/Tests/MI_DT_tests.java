package Tests;

import Helpers.Helpers;
import Pages.MI_DT.Login;
import Pages.MI_DT.Roles;
import baseClass.baseClass;

import org.junit.Test;

import static org.junit.Assert.assertEquals;


public class MI_DT_tests extends baseClass {

    String username = "18580616-2";
    String password = "Barbatos123!";
    String URL = "https://www.dt.gob.cl/";

    public Helpers IniciarSesionClaveUnica() {
        Helpers helpers = new Helpers(driver);
        helpers.goToURL(URL);
        Login login = new Login(driver);
        login.goToMIDT();
        login.iniciarSesionClaveUnica(username, password);
        return helpers;
    }


    @Test
    public void Mi_DT_Test_Roles_Trabajador() throws InterruptedException {
        Helpers h = IniciarSesionClaveUnica();
        Roles roles = new Roles(driver);

        roles.seleccionPerfilTrabajador();
        assertEquals("La URL no es la esperada", "https://midt.dirtrab.cl/trabajador/home", h.returnURL());

    }

    @Test
    public void Mi_DT_Test_Roles_Empleador() throws InterruptedException {
        IniciarSesionClaveUnica();
    }

    @Test
    public void Mi_DT_Test_Roles_Dirigente_Sindical() throws InterruptedException {
        IniciarSesionClaveUnica();
    }

    @Test
    public void Mi_DT_Test_Roles_Manual_De_Usuario() throws InterruptedException {
        IniciarSesionClaveUnica();
    }

    @Test
    public void Mi_DT_Test_Roles_Verificador_De_Documentos() throws InterruptedException {
        IniciarSesionClaveUnica();
    }

}
